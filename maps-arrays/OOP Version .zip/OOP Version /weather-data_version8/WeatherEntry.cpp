#include "WeatherEntry.h"

WeatherEntry::WeatherEntry(double _temperature[], std::string _timestamp, const std::vector<std::string>& countryCodes)
        : timestamp(_timestamp), country(countryCodes) {
    for (int i = 1; i < countryCodes.size(); ++i) {
        std::string countryCode = countryCodes[i].substr(0, 2); // Extract country code from header
        WeatherNode weatherNode(_temperature[i - 1], countryCode);
        weather.push_back(weatherNode);
    }
}

void WeatherEntry::insertWeather(double _temperature, int countryIndex, std::string _timestamp) {
    timestamp = _timestamp;
    std::string countryCode = countryIndex < 29 ? country[countryIndex] : "Unknown";
    WeatherNode weatherNode(_temperature, countryCode);
    weather.push_back(weatherNode);
}

#include "WeatherCSVReader.h"
#include <iostream>
#include <fstream>

WeatherCSVReader::WeatherCSVReader() {
}

std::string WeatherCSVReader::extractDate(const std::string& timestamp) {
    return timestamp.substr(0, 10); // Assuming timestamp format is "YYYY-MM-DD HH:MM:SS"
}

std::string WeatherCSVReader::extractTime(const std::string& timestamp) {
    return timestamp.substr(11, 8); // Assuming timestamp format is "YYYY-MM-DD HH:MM:SS"
}

std::vector<WeatherEntry> WeatherCSVReader::readCSV(std::string csvFilename) {
    std::vector<WeatherEntry> entries;
    std::vector<std::string> countryCodes;

    std::ifstream csvFile{csvFilename};
    std::string line;

    if (csvFile.is_open()) {
        // Read the header line
        if (std::getline(csvFile, line)) {
            countryCodes = tokenise(line, ',');
        }

        while (std::getline(csvFile, line)) {
            try {
                WeatherEntry weatherRecord = stringsToWBE(tokenise(line, ','), countryCodes);
                entries.push_back(weatherRecord);
            } catch (const std::exception &e) {
                std::cout << "CSVReader::readCSV bad data" << std::endl;
            }
        }
    }

    std::cout << "CSVReader::readCSV read " << entries.size() << " entries" << std::endl;
    return entries;
}

std::vector<std::string> WeatherCSVReader::tokenise(std::string csvLine, char separator) {
    std::vector<std::string> tokens;
    signed int start, end;
    std::string token;
    start = csvLine.find_first_not_of(separator, 0);
    do {
        end = csvLine.find_first_of(separator, start);
        if (start == csvLine.length() || start == end)
            break;
        if (end >= 0)
            token = csvLine.substr(start, end - start);
        else
            token = csvLine.substr(start, csvLine.length() - start);
        tokens.push_back(token);
        start = end + 1;
    } while (end > 0);

    return tokens;
}

WeatherEntry WeatherCSVReader::stringsToWBE(std::vector<std::string> tokens, const std::vector<std::string>& countryCodes) {
    double temprature[28] = {0}; // Adjusted to 28 to match the actual temperature columns
    std::string timestamp = tokens[0];

    //std::cout << "Token Size = " << tokens.size() << std::endl;
    //std::cout << "Country Code Size = " << countryCodes.size() << std::endl;

    if (tokens.size() != 29) // Check for the correct number of columns
    {
        std::cout << "Bad line " << std::endl;
        throw std::exception{};
    }

    // Extract temperature values
    try {
        for (int i = 1; i < 29; ++i) {
            temprature[i - 1] = std::stod(tokens[i]);
        }
    } catch (const std::exception &e) {
        std::cout << "CSVReader::stringsToOBE Bad float! " << tokens[3] << std::endl;
        std::cout << "CSVReader::stringsToOBE Bad float! " << tokens[4] << std::endl;
        throw;
    }

    WeatherEntry weatherEntry{
            temprature,
            timestamp,
            countryCodes
    };

    return weatherEntry;
}

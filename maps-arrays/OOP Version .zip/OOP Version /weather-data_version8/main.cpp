#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <map>
#include "WeatherCSVReader.h"
#include "WeatherEntry.h"
#include "WeatherNode.h"

// Map of European countries with their codes
std::map<std::string, std::string> europeanCountries = {
        {"Austria", "AT"}, {"Belgium", "BE"}, {"Bulgaria", "BG"}, {"Switzerland", "CH"},
        {"Czech Republic", "CZ"}, {"Germany", "DE"}, {"Denmark", "DK"}, {"Estonia", "EE"},
        {"Spain", "ES"}, {"Finland", "FI"}, {"France", "FR"}, {"United Kingdom", "GB"},
        {"Greece", "GR"}, {"Croatia", "HR"}, {"Hungary", "HU"}, {"Ireland", "IE"},
        {"Italy", "IT"}, {"Lithuania", "LT"}, {"Luxembourg", "LU"}, {"Latvia", "LV"},
        {"Netherlands", "NL"}, {"Norway", "NO"}, {"Poland", "PL"}, {"Portugal", "PT"},
        {"Romania", "RO"}, {"Sweden", "SE"}, {"Slovenia", "SI"}, {"Slovakia", "SK"}
};

std::string csvFilename = "/Users/oxon/Documents/OOP Version /weather-data_version8/weather_data_EU_1980-2019_temp_only.csv";
// Map of European countries with their codes


std::map<std::string, std::map<std::string, std::map<std::string, int>>> weatherData;
std::map<std::string, std::map<std::string, int>> highTemperatures;
std::map<std::string, std::map<std::string, int>> lowTemperatures;
std::map<std::string, std::map<std::string, int>> openTemperatures;
std::map<std::string, std::map<std::string, int>> closeTemperatures;

void displayHighLowOpenCloseTemp(const std::string& selectedDate, const std::string& selectedCountry);
void plotCandlestickGraph(int month, int year, const std::string& countryCode);



int main() {
  //  std::string csvFilename = "weather.csv"; // Change this to your CSV file path
    std::vector<WeatherEntry> weatherEntries = WeatherCSVReader::readCSV(csvFilename);

    // Debug output: print weather entries
    std::cout << "Read " << weatherEntries.size() << " weather entries:" << std::endl;
    /*for (const auto& entry : weatherEntries) {
        std::cout << "Timestamp: " << entry.timestamp << std::endl;
        for (const auto& weatherNode : entry.weather) {
            std::cout << weatherNode << std::endl;
        }
    }
*/
    // Populate the weatherData map from weatherEntries
    std::cout << "Populating weatherData map..." << std::endl;
    for (const auto& entry : weatherEntries) {
        std::string date = WeatherCSVReader::extractDate(entry.timestamp);
        std::string time = WeatherCSVReader::extractTime(entry.timestamp);

        for (const auto& weatherNode : entry.weather) {
            std::string countryCode = weatherNode.getCountry();
            int temperature = static_cast<int>(weatherNode.getTemperature());

            // Update weather data map
            weatherData[date][countryCode][time] = temperature;

            // Initialize high and low temperatures if they don't exist
            if (highTemperatures[date].find(countryCode) == highTemperatures[date].end()) {
                highTemperatures[date][countryCode] = temperature;
                lowTemperatures[date][countryCode] = temperature;
            }

            // Update high temperatures
            if (highTemperatures[date][countryCode] < temperature) {
                highTemperatures[date][countryCode] = temperature;
            }

            // Update low temperatures
            if (lowTemperatures[date][countryCode] > temperature) {
                lowTemperatures[date][countryCode] = temperature;
            }

            // Update open temperatures (first temperature of the day at 00:00:00)
            if (time == "00:00:00") {
                openTemperatures[date][countryCode] = temperature;
            }

            // Update close temperatures (last temperature of the day at 23:00:00)
            if (time == "23:00:00") {
                closeTemperatures[date][countryCode] = temperature;
            }
        }
    }

    // Debug output: print high, low, open, and close temperatures
    std::cout << "High, Low, Open, and Close temperatures:" << std::endl;
    for (const auto& outerPair : highTemperatures) {
        const std::string& date = outerPair.first;
        const auto& countryMap = outerPair.second;
        std::cout << "Date: " << date << std::endl;
        for (const auto& countryPair : countryMap) {
            const std::string& countryCode = countryPair.first;
            int highTemp = countryPair.second;
            int lowTemp = lowTemperatures[date][countryCode];
            int openTemp = openTemperatures[date][countryCode];
            int closeTemp = closeTemperatures[date][countryCode];
            std::cout << "  Country: " << countryCode << ", High: " << highTemp << ", Low: " << lowTemp
                      << ", Open: " << openTemp << ", Close: " << closeTemp << std::endl;
        }
    }

    std::string selectedDate = "1980-01-03";
    std::string selectedCountry = "PT";
    displayHighLowOpenCloseTemp(selectedDate, selectedCountry);

    // Example usage of plotCandlestickGraph function
    int month = 1; // January
    int year = 1980;
    plotCandlestickGraph(month, year, "PT");

    return 0;
}

void displayHighLowOpenCloseTemp(const std::string& selectedDate, const std::string& selectedCountry) {
    if (highTemperatures.find(selectedDate) != highTemperatures.end() && highTemperatures[selectedDate].find(selectedCountry) != highTemperatures[selectedDate].end()) {
        int highTemp = highTemperatures[selectedDate][selectedCountry];
        int lowTemp = lowTemperatures[selectedDate][selectedCountry];
        int openTemp = openTemperatures[selectedDate][selectedCountry];
        int closeTemp = closeTemperatures[selectedDate][selectedCountry];
        std::cout << "High temperature for " << selectedCountry << " on " << selectedDate << ": " << highTemp << std::endl;
        std::cout << "Low temperature for " << selectedCountry << " on " << selectedDate << ": " << lowTemp << std::endl;
        std::cout << "Open temperature for " << selectedCountry << " on " << selectedDate << ": " << openTemp << std::endl;
        std::cout << "Close temperature for " << selectedCountry << " on " << selectedDate << ": " << closeTemp << std::endl;
    } else {
        std::cout << "No data found for " << selectedCountry << " on " << selectedDate << std::endl;
    }
}

//void plotCandlestickGraph(int month, int year, const std::string& countryCode) {
//    // Determine the number of days in the month
//    int daysInMonth = 30; // Simplified for this example. You may want to handle different month lengths.
//
//    std::vector<int> highTemps(daysInMonth, INT_MIN);
//    std::vector<int> lowTemps(daysInMonth, INT_MAX);
//    std::vector<int> openTemps(daysInMonth, INT_MIN);
//    std::vector<int> closeTemps(daysInMonth, INT_MIN);
//
//    // Extract data for the given month, year, and country
//    for (int day = 1; day <= daysInMonth; ++day) {
//        std::string date = std::to_string(year) + "-" + (month < 10 ? "0" : "") + std::to_string(month) + "-" + (day < 10 ? "0" : "") + std::to_string(day);
//        if (highTemperatures.find(date) != highTemperatures.end() && highTemperatures[date].find(countryCode) != highTemperatures[date].end()) {
//            highTemps[day - 1] = highTemperatures[date][countryCode];
//            lowTemps[day - 1] = lowTemperatures[date][countryCode];
//            openTemps[day - 1] = openTemperatures[date][countryCode];
//            closeTemps[day - 1] = closeTemperatures[date][countryCode];
//        }
//    }
//
//    // Determine the range of temperatures for the y-axis
//    int globalHighTemp = *std::max_element(highTemps.begin(), highTemps.end());
//    int globalLowTemp = *std::min_element(lowTemps.begin(), lowTemps.end());
//
//    // Generate the text-based candlestick graph
//    std::cout << "\nCandlestick graph for " << countryCode << " in " << year << "-" << (month < 10 ? "0" : "") << month << ":\n";
//    for (int temp = globalHighTemp; temp >= globalLowTemp; --temp) {
//        std::cout << (temp < 10 ? " " : "") << temp << " |";
//        for (int day = 0; day < daysInMonth; ++day) {
//            if (highTemps[day] != INT_MIN && lowTemps[day] != INT_MAX) {
//                std::cout << " ";
//                if (temp <= highTemps[day] && temp >= lowTemps[day]) {
//                    if (temp == highTemps[day] || temp == lowTemps[day]) {
//                        std::cout << " | "; // High and Low temperatures
//                    } else if (temp == openTemps[day] && temp == closeTemps[day]) {
//                        std::cout << "___"; // Open and Close temperatures are the same
//                    } else if (temp == openTemps[day]) {
//                        std::cout << "___"; // Open temperature
//                    } else if (temp == closeTemps[day]) {
//                        std::cout << "---"; // Close temperature
//                    } else {
//                        std::cout << " | "; // Temperatures in between
//                    }
//                } else {
//                    std::cout << " | ";
//                }
//                std::cout << "  "; // Add a space between candlesticks
//            } else {
//                std::cout << "  "; // Add space for missing data
//            }
//        }
//        std::cout << "\n";
//    }
//
//    // Print x-axis labels
//    std::cout << "     ";
//    for (int day = 1; day <= daysInMonth; ++day) {
//        std::cout << (day < 10 ? " " : "") << day << "  ";
//    }
//    std::cout << "\n";
//}

void plotCandlestickGraph(int month, int year, const std::string& countryCode) {
    int daysInMonth = 30; // Simplified for this example. You may want to handle different month lengths.
    const int columnWidth = 5; // Fixed width for each column

    std::vector<int> highTemps(daysInMonth, INT_MIN);
    std::vector<int> lowTemps(daysInMonth, INT_MAX);
    std::vector<int> openTemps(daysInMonth, INT_MIN);
    std::vector<int> closeTemps(daysInMonth, INT_MIN);

    for (int day = 1; day <= daysInMonth; ++day) {
        std::string date = std::to_string(year) + "-" + (month < 10 ? "0" : "") + std::to_string(month) + "-" + (day < 10 ? "0" : "") + std::to_string(day);
        if (highTemperatures.find(date) != highTemperatures.end() && highTemperatures[date].find(countryCode) != highTemperatures[date].end()) {
            highTemps[day - 1] = highTemperatures[date][countryCode];
            lowTemps[day - 1] = lowTemperatures[date][countryCode];
            openTemps[day - 1] = openTemperatures[date][countryCode];
            closeTemps[day - 1] = closeTemperatures[date][countryCode];
        }
    }

    int globalHighTemp = *std::max_element(highTemps.begin(), highTemps.end());
    int globalLowTemp = *std::min_element(lowTemps.begin(), lowTemps.end());

    std::cout << "\nCandlestick graph for " << countryCode << " in " << year << "-" << (month < 10 ? "0" : "") << month << ":\n";

    for (int temp = globalHighTemp; temp >= globalLowTemp; --temp) {
        std::cout << (temp < 10 && temp > -10 ? " " : "") << temp << " |";
        for (int day = 0; day < daysInMonth; ++day) {
            std::string cell = "     "; // Start with a blank cell of fixed width
            if (highTemps[day] != INT_MIN && lowTemps[day] != INT_MAX) {
                if (temp == highTemps[day] || temp == lowTemps[day]) {
                    cell = "  |  "; // High and Low temperatures
                } else if (temp == openTemps[day] && temp == closeTemps[day]) {
                    cell = " ___ "; // Open and Close temperatures are the same
                } else if (temp == openTemps[day]) {
                    cell = " -*- "; // Open temperature
                } else if (temp == closeTemps[day]) {
                    cell = " -*- "; // Close temperature
                } else if (temp < highTemps[day] && temp > lowTemps[day]) {
                    cell = "  |  "; // Temperatures in between
                }
            }
            std::cout << cell;
        }
        std::cout << "\n";
    }

    // Print x-axis labels
    std::cout << "      ";
    for (int day = 1; day <= daysInMonth; ++day) {
        std::cout << std::setw(columnWidth) << day;
    }
    std::cout << "\n";
}

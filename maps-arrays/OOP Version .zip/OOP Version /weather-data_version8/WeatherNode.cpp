#include "WeatherNode.h"

WeatherNode::WeatherNode(double _temperature, const std::string& _country)
        : temperature(_temperature), country(_country) {
}

double WeatherNode::getTemperature() const {
    return temperature;
}

std::string WeatherNode::getCountry() const {
    return country;
}

std::ostream& operator<<(std::ostream& os, const WeatherNode& node) {
    os << "Country: " << node.country << ", Temperature: " << node.temperature;
    return os;
}

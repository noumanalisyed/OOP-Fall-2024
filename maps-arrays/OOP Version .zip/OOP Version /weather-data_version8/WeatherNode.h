#pragma once

#include <string>
#include <iostream>

class WeatherNode {
public:
    WeatherNode(double _temperature, const std::string& _country);

    double getTemperature() const;
    std::string getCountry() const;

    friend std::ostream& operator<<(std::ostream& os, const WeatherNode& node);

private:
    double temperature;
    std::string country;
};
